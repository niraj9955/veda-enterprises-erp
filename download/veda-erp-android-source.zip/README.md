# Veda ERP — Android App

Native Android WebView app that wraps the Veda ERP web application
(https://veda-enterprises-erp.vercel.app/).

## Project Info

| Property        | Value                                       |
|-----------------|---------------------------------------------|
| Application ID  | `com.veda.enterprises`                      |
| Version         | 1.0.2 (versionCode 3)                       |
| Min SDK         | Android 7.0 (API 24)                        |
| Target SDK      | Android 14 (API 34)                         |
| Compile SDK     | 34                                          |
| Java            | 17 (Java 21 also supported by Gradle 8.5+)  |
| Gradle          | 8.5 (wrapper included)                      |
| AGP             | 8.2.2                                       |
| Default URL     | https://veda-enterprises-erp.vercel.app/    |

## ⚡ Quick Start (Android Studio)

### Step 1 — Requirements
Make sure you have:
- **Android Studio Iguana (2023.2.1)** or newer (Hedgehog also works)
- **JDK 17 or JDK 21** — both are supported. Android Studio bundles JDK 17.
  - Verify in: `File → Settings → Build, Execution, Deployment → Build Tools → Gradle → Gradle JDK`
- Internet connection (first sync downloads Gradle 8.5 + Android SDK 34)

### Step 2 — Clone or Download
```bash
git clone https://github.com/niraj9955/veda-erp-android.git
```
Or download the ZIP and extract it.

### Step 3 — Open in Android Studio
1. Open Android Studio
2. `File → Open…` → select the project folder
3. Wait for Gradle sync to complete (first time: ~3–5 min)

### Step 4 — Run
- Connect an Android device (USB debugging on) OR start an emulator
- Click the green ▶ Run button
- App will install and launch

---

## 🔧 If You See "Gradle Sync Failed"

This usually happens when Android Studio's Gradle cache is corrupt or
when the Gradle wrapper wasn't included in the ZIP. This project now
ships with the full Gradle wrapper (`gradlew`, `gradlew.bat`,
`gradle/wrapper/*`), so the following steps should fix it:

### Fix 1 — Use the included Gradle wrapper
Open Android Studio's **Terminal** (View → Tool Windows → Terminal)
and run:
```bash
# Windows
gradlew.bat --stop
gradlew.bat assembleDebug

# Mac/Linux
./gradlew --stop
./gradlew assembleDebug
```

### Fix 2 — Re-download dependencies
In Android Studio's Build output window, click the blue link:
> "Re-download dependencies and sync project (requires network)"

### Fix 3 — Invalidate caches
`File → Invalidate Caches… → Invalidate and Restart`

### Fix 4 — Delete .gradle folder manually
Close Android Studio, then delete:
```
<project>/.gradle/
<project>/app/build/
<home>/.gradle/caches/        (global Gradle cache)
```
Reopen Android Studio → it will re-download everything fresh.

### Fix 5 — Check Gradle JDK
`File → Settings → Build → Gradle → Gradle JDK` should be set to:
- **JDK 17** (recommended, bundled with Android Studio), OR
- **JDK 21** (works with Gradle 8.5+ which this project uses)

Both work. The previous error "Gradle 8.1.1 incompatible with JDK 21"
is fixed — this project now uses Gradle 8.5 which supports JDK 21.

---

## How to Build a Signed Release APK

### Option A — Use the existing keystore (already included)

A pre-made signing keystore is included (`veda-release.keystore`):

| Property        | Value           |
|-----------------|-----------------|
| Alias           | `veda-key`      |
| Password        | `veda1234`      |
| Validity        | 30 years        |

The `app/build.gradle` already has the signing config wired up.

**From Android Studio:**
`Build → Generate Signed Bundle / APK → APK →
 Choose existing: veda-release.keystore
 Key alias: veda-key
 Key password: veda1234 → Release → Build`

**From command line:**
```bash
# Windows
gradlew.bat assembleRelease

# Mac/Linux
./gradlew assembleRelease
```

The signed APK will be at:
`app/build/outputs/apk/release/app-release.apk`

### Option B — Generate your own keystore (recommended for production)

```bash
keytool -genkey -v -keystore veda-release.keystore ^
  -alias veda-key -keyalg RSA -keysize 2048 -validity 10000
```

Then update `app/build.gradle` → `signingConfigs.release` with the new
passwords.

## How to Change the Default URL

Two ways:

1. **At build time** — edit `app/src/main/res/values/strings.xml`:
   ```xml
   <string name="defaultUrl">https://your-new-url.com/</string>
   ```

2. **At runtime** — open the app → if it fails to load, tap
   "सर्वर URL सेटिंग्स" → enter new URL → save. App restarts automatically.

## App Features

- Splash screen with Veda logo (1.5s)
- Full-screen WebView with JavaScript, cookies, DOM storage
- File upload support (single + multi-file chooser)
- Geolocation auto-granted
- Camera / microphone permission handling
- External links open in browser (tel:, mailto:, wa:, sms:)
- Download listener (downloads open in browser)
- Back button navigates WebView history, then exits
- Hindi error screen with Retry + Settings buttons
- User-configurable server URL
- Adaptive icon (Android 8.0+) with Veda logo
- Emerald green theme (#10B981 / #047857)
- Portrait orientation lock
- Cleartext HTTP allowed (for local development)

## Project Structure

```
veda-erp-android/
├── build.gradle                    (root)
├── settings.gradle
├── gradle.properties
├── gradlew                         (Linux/Mac wrapper)
├── gradlew.bat                     (Windows wrapper)
├── gradle/wrapper/
│   ├── gradle-wrapper.jar
│   └── gradle-wrapper.properties
├── veda-release.keystore           (signing key)
├── README.md                       (this file)
└── app/
    ├── build.gradle                (app module config)
    ├── proguard-rules.pro
    └── src/main/
        ├── AndroidManifest.xml
        ├── java/com/veda/enterprises/
        │   ├── MainActivity.java   (WebView host)
        │   └── SettingsActivity.java (URL config screen)
        └── res/
            ├── drawable/
            │   ├── splash_background.xml
            │   ├── ic_launcher_background.xml  (adaptive icon bg)
            │   ├── ic_launcher_foreground.xml  (adaptive icon fg)
            │   └── ic_launcher_foreground.png  (Veda logo, 432x432)
            ├── layout/
            │   ├── activity_main.xml           (WebView + splash + error)
            │   └── activity_settings.xml       (URL edit form)
            ├── mipmap-anydpi-v26/
            │   ├── ic_launcher.xml             (adaptive icon)
            │   └── ic_launcher_round.xml
            ├── mipmap-mdpi/    (48x48 icons)
            ├── mipmap-hdpi/    (72x72 icons)
            ├── mipmap-xhdpi/   (96x96 icons)
            ├── mipmap-xxhdpi/  (144x144 icons)
            ├── mipmap-xxxhdpi/ (192x192 icons)
            ├── values/
            │   ├── strings.xml                 (app name + default URL)
            │   ├── colors.xml                  (emerald theme)
            │   └── styles.xml                  (Theme.VedaERP)
            └── xml/
                └── network_security_config.xml (allows HTTP+HTTPS)
```

## Signing Info (Existing Keystore)

⚠️ **For production**: Generate your own keystore before publishing to Play Store.
Using the bundled keystore publicly is a security risk — anyone can sign
updates to your app with it.

The bundled keystore is for **development/internal distribution only**.

---

© Veda Enterprises
